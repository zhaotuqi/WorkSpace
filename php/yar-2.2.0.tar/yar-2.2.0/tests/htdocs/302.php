<?php
header("Location: http://www.laruence.com");
